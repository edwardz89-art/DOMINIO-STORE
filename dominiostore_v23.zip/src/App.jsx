import React, { useState } from 'react';

const PHONE_NUMBER = '51990105444'; // +51 990105444

const products = [
  {
    id: 1,
    brand: 'Nike',
    title: 'Nike Air Zoom',
    price: 299.99,
    img: 'https://via.placeholder.com/800x600?text=Nike+Air+Zoom',
    color: 'Rojo',
    sku: 'N-AZ-001',
    description: 'Zapatillas de alto rendimiento con amortiguación Air Zoom, ideales para correr y entrenar.',
  },
  {
    id: 2,
    brand: 'Adidas',
    title: 'Adidas Runner',
    price: 259.99,
    img: 'https://via.placeholder.com/800x600?text=Adidas+Runner',
    color: 'Gris',
    sku: 'A-RU-002',
    description: 'Diseño liviano y cómodo para todo tipo de actividad deportiva o uso diario.',
  },
  {
    id: 3,
    brand: 'Nike',
    title: 'Nike Street',
    price: 189.99,
    img: 'https://via.placeholder.com/800x600?text=Nike+Street',
    color: 'Gris',
    sku: 'N-ST-003',
    description: 'Zapatillas urbanas con estilo moderno y suela resistente para el día a día.',
  },
  {
    id: 4,
    brand: 'Adidas',
    title: 'Adidas Sport',
    price: 219.99,
    img: 'https://via.placeholder.com/800x600?text=Adidas+Sport',
    color: 'Rojo',
    sku: 'A-SP-004',
    description: 'Perfectas para el entrenamiento. Tecnología de soporte en el talón y ventilación avanzada.',
  },
];

export default function App() {
  const [page, setPage] = useState('inicio'); // inicio | catalogo | producto
  const [selected, setSelected] = useState(null);
  const [query, setQuery] = useState('');
  const [brandFilter, setBrandFilter] = useState('Todos');

  const filtered = products.filter(
    (p) =>
      [p.title, p.brand, p.sku, p.color].join(' ').toLowerCase().includes(query.toLowerCase()) &&
      (brandFilter === 'Todos' ? true : p.brand === brandFilter)
  );

  function openWhatsApp(product, extra='') {
    const text = encodeURIComponent(
      extra ||
      `Hola, quiero pedir *${product.title}* (SKU: ${product.sku}). Precio: S/ ${product.price.toFixed(
        2
      )}. ¿Está disponible en talla...?`
    );
    const url = `https://wa.me/${PHONE_NUMBER}?text=${text}`;
    window.open(url, '_blank');
  }

  function renderInicio() {
    return (
      <section className="max-w-6xl mx-auto px-6 py-10 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h2 className="text-4xl font-extrabold mb-4">DOMINIO STORE</h2>
          <p className="mb-6 text-lg opacity-90">
            Tienda online de zapatillas Nike y Adidas. Originales, nuevos y con envío a todo Perú.
          </p>
          <div className="flex gap-3">
            <button onClick={() => setPage('catalogo')} className="bg-red-600 text-white px-5 py-3 rounded-lg font-semibold">
              Ver catálogo
            </button>
            <button
              onClick={() => window.open(`https://wa.me/${PHONE_NUMBER}?text=${encodeURIComponent('Hola, quiero más información')}`)}
              className="border border-red-600 px-5 py-3 rounded-lg font-semibold text-red-600 bg-white"
            >
              Contactar por WhatsApp
            </button>
          </div>
        </div>
        <img
          src="https://via.placeholder.com/900x600?text=DOMINIO+STORE"
          alt="Dominio Store"
          className="rounded-xl shadow-xl"
        />
      </section>
    );
  }

  function renderCatalogo() {
    return (
      <section className="max-w-6xl mx-auto px-6 py-10">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-4">
          <div className="flex gap-3 items-center">
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar producto..."
              className="px-4 py-2 border rounded-lg w-64"
            />
            <select value={brandFilter} onChange={(e) => setBrandFilter(e.target.value)} className="px-3 py-2 border rounded-lg">
              <option>Todos</option>
              <option>Nike</option>
              <option>Adidas</option>
            </select>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={() => setPage('inicio')} className="text-sm underline">Volver al inicio</button>
            <div className="text-sm opacity-80">Mostrando <strong>{filtered.length}</strong> productos</div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((p) => (
            <article key={p.id} className="bg-white rounded-2xl p-4 shadow hover:shadow-xl transition">
              <img src={p.img} alt={p.title} className="rounded-lg mb-4" />
              <h3 className="font-bold text-lg">{p.title}</h3>
              <p className="text-sm opacity-80">{p.brand} • {p.color}</p>
              <p className="font-semibold mt-2">S/ {p.price.toFixed(2)}</p>
              <div className="mt-4 flex gap-2">
                <button onClick={() => { setSelected(p); setPage('producto'); }} className="px-4 py-2 bg-gray-200 rounded-lg text-sm font-medium">
                  Ver detalles
                </button>
                <button onClick={() => openWhatsApp(p)} className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium">
                  Pedir
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>
    );
  }

  function renderProducto() {
    const p = selected;
    if (!p) return null;
    return (
      <section className="max-w-5xl mx-auto px-6 py-10">
        <button onClick={() => setPage('catalogo')} className="text-sm underline mb-4 block">← Volver al catálogo</button>
        <div className="grid md:grid-cols-2 gap-8 items-start">
          <img src={p.img} alt={p.title} className="rounded-xl shadow-lg" />
          <div>
            <h2 className="text-3xl font-bold mb-2">{p.title}</h2>
            <p className="text-lg opacity-80 mb-2">{p.brand} • {p.color}</p>
            <p className="font-bold text-2xl mb-4">S/ {p.price.toFixed(2)}</p>
            <p className="mb-6 opacity-90">{p.description}</p>
            <button onClick={() => openWhatsApp(p)} className="bg-red-600 text-white px-6 py-3 rounded-lg font-semibold">
              Pedir por WhatsApp
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 flex flex-col">
      <header className="bg-gradient-to-r from-red-600 to-gray-700 text-white">
        <div className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.svg" alt="DS" className="w-12 h-12 rounded" />
            <div className="font-bold text-xl">DOMINIO STORE</div>
          </div>
          <nav className="hidden md:flex items-center gap-4">
            <button onClick={() => setPage('inicio')} className="hover:underline text-sm">Inicio</button>
            <button onClick={() => setPage('catalogo')} className="hover:underline text-sm">Catálogo</button>
            <a href="#contacto" onClick={() => setPage('inicio')} className="hover:underline text-sm">Contacto</a>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        {page === 'inicio' && renderInicio()}
        {page === 'catalogo' && renderCatalogo()}
        {page === 'producto' && renderProducto()}
      </main>

      <footer className="mt-12 py-8 text-sm text-gray-700 border-t bg-white">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-3 gap-6">
          <div>
            <h4 className="font-bold mb-2">DOMINIO STORE</h4>
            <p className="opacity-90">Zapatillas originales • Envíos a todo Perú</p>
          </div>
          <div id="contacto">
            <h5 className="font-semibold">Contacto</h5>
            <p>WhatsApp: <a href={`https://wa.me/${PHONE_NUMBER}`} target="_blank" rel="noreferrer" className="text-red-600">+51 990105444</a></p>
            <p>Email: <a href="mailto:ventas@dominiostore.com">ventas@dominiostore.com</a></p>
            <p>Dirección: Lima, Perú (ejemplo)</p>
          </div>
          <div>
            <h5 className="font-semibold">Redes</h5>
            <p><a href="https://instagram.com/" target="_blank" rel="noreferrer" className="underline">Instagram</a></p>
            <p><a href="https://facebook.com/" target="_blank" rel="noreferrer" className="underline">Facebook</a></p>
          </div>
        </div>
        <div className="max-w-6xl mx-auto px-6 text-center mt-6 text-gray-500">
          © {new Date().getFullYear()} DOMINIO STORE — dominiostore.vercel.app
        </div>
      </footer>
    </div>
  );
}
